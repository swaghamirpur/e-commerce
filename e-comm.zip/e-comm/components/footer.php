<footer class="footer">

   <section class="grid">

      <div class="box">
         <h3>Quick Links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> Shop</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact</a>
      </div>

      <div class="box">
         <h3>Extra Links</h3>
         <a href="user_login.php"> <i class="fas fa-angle-right"></i> Login</a>
         <a href="user_register.php"> <i class="fas fa-angle-right"></i> Register</a>
         <a href="cart.php"> <i class="fas fa-angle-right"></i> Cart</a>
         <a href="orders.php"> <i class="fas fa-angle-right"></i> Orders</a>
      </div>

      <div class="box">
         <h3>Contact Us</h3>
         <a href="+91 7087853621"><i class="fas fa-phone"></i> +91 9015069543 </a>
         <a href="+91 7087853621"><i class="fas fa-phone"></i> +91 9015069543</a>
         <a href="mailto:rohanpandit773@gmail.com"><i class="fas fa-envelope"></i>rohanpandit773@gmail.com</a>
         <a href="https://www.google.com/myplace"><i class="fas fa-map-marker-alt"></i> Shoolini University, Bajhol </a>
      </div>

      <div class="box">
         <h3>Follow Us</h3>
         <a href="#"><i class="fab fa-facebook-f"></i>Facebook</a>
         <a href="#"><i class="fab fa-twitter"></i>Twitter</a>
         <a href="https://www.instagram.com/rohan_pandit.15?igsh=NGVhN2U2NjQ0Yg=="><i class="fab fa-instagram"></i>Instagram</a>
         <a href="#"><i class="fab fa-linkedin"></i>Linkedin</a>
      </div>

   </section>

   <div class="credit"&copy> &copy;<span id="currentYear"></span> e-store <br>made by Rohan Pandit </div>
   <script>
  // Get the current year
  let currentDate = new Date();
  let currentYear = currentDate.getFullYear();

  // Find the element with the id "currentYear"
  let currentYearElement = document.getElementById("currentYear");

  // Update the content of the element with the current year
  currentYearElement.textContent = currentYear;
</script>

</footer>